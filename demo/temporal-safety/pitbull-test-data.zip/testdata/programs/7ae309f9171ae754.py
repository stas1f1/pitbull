def get_features(db, entity_ids, seed_time):
    # вход: db - словарь с таблицами, entity_ids - list/array product_id, seed_time - Timestamp
    # выход: DataFrame с признаками, индексированный по entity_ids

    # Загружаем таблицы
    orders = db['orders']
    order_items = db['order_items']
    reviews = db['reviews']
    payments = db['payments']

    # Фильтруем order_items по продуктам и по времени <= seed_time
    items = order_items[order_items['product_id'].isin(entity_ids)].copy()
    items = items[items['ts'] <= seed_time]

    # Присоединяем customer_id из orders
    items = items.merge(orders[['order_id', 'customer_id']], on='order_id', how='left')

    # Агрегируем платежи по order_id
    pay_agg = payments.groupby('order_id').agg(
        tot_payment=('payment_value', 'sum'),
        n_payments=('payment_sequential', 'count'),
        avg_installments=('payment_installments', 'mean'),
        n_payment_types=('payment_type', 'nunique')
    ).reset_index()
    items = items.merge(pay_agg, on='order_id', how='left')

    # Окна для исторических признаков (в днях)
    windows = [7, 30, 90, 180, 365]

    # Инициализируем список фреймов признаков
    feature_frames = []

    # Константные признаки, зависящие только от seed_time
    seed_feats = pd.DataFrame({
        'seed_month': [seed_time.month] * len(entity_ids),
        'seed_quarter': [seed_time.quarter] * len(entity_ids),
        'seed_dayofweek': [seed_time.dayofweek] * len(entity_ids)
    }, index=entity_ids)
    feature_frames.append(seed_feats)

    for w in windows:
        start_date = seed_time - pd.Timedelta(days=w)

        # Срезаем данные по текущему окну
        win_items = items[items['ts'] >= start_date]

        # Агрегация по товарам для данного окна
        agg = {}
        if not win_items.empty:
            grp = win_items.groupby('product_id')
            agg = grp.agg(
                n_items=('order_id', 'count'),
                n_orders=('order_id', 'nunique'),
                n_customers=('customer_id', 'nunique'),
                total_price=('price', 'sum'),
                total_freight=('freight_value', 'sum'),
                avg_price=('price', 'mean'),
                avg_freight=('freight_value', 'mean'),
                total_payment=('tot_payment', 'sum'),
                avg_payment_per_order=('tot_payment', 'mean'),
                avg_installments=('avg_installments', 'mean'),
                n_payment_types=('n_payment_types', 'mean'),
                n_payments=('n_payments', 'sum')
            )
            # Время последней и первой покупки в окне
            last_ts = grp['ts'].max()
            first_ts = grp['ts'].min()
            agg['time_since_last_purchase'] = (seed_time - last_ts).dt.days
            agg['time_since_first_purchase'] = (seed_time - first_ts).dt.days
            agg = agg.copy()  # чтобы безопасно добавлять колонки
        else:
            agg = pd.DataFrame(index=pd.Index(entity_ids, name='product_id'))

        # Отзывы для текущего окна
        if not win_items.empty:
            order_ids_in_win = win_items['order_id'].unique()
            rev = reviews[reviews['order_id'].isin(order_ids_in_win)]
            # product -> order_id mapping
            product_order = win_items[['product_id', 'order_id']].drop_duplicates()
            rev_merged = product_order.merge(rev, on='order_id', how='inner')
            if not rev_merged.empty:
                rev_grp = rev_merged.groupby('product_id')['review_score']
                rev_agg = rev_grp.agg(
                    rev_count='count',
                    rev_mean='mean',
                    rev_high= lambda x: (x >= 4).mean() * 100.0
                )
            else:
                rev_agg = pd.DataFrame()
        else:
            rev_agg = pd.DataFrame()

        # Добавляем рейтинговые признаки
        if not rev_agg.empty:
            agg = agg.join(rev_agg, how='left')
        else:
            agg['rev_mean'] = np.nan
            agg['review_count'] = 0
            agg['rev_high'] = 0.0

        # Исправляем возможные дубликаты (если есть) и NaN во временных колонках
        for col in ['time_since_last_purchase', 'time_since_first_purchase']:
            if col not in agg.columns:
                agg[col] = np.nan

        # Переименовываем с префиксом окна
        agg.columns = [f'win_{w}_{col}' for col in agg.columns]

        # Убираем индекс product_id (он в индексе уже)
        feature_frames.append(agg)

    # Объединяем все признаки по оси столбцов
    result = pd.concat(feature_frames, axis=1)

    # реиндексируем под entity_ids, заполняем пропуски нулями
    result = result.reindex(entity_ids, fill_value=0)
    result = result.fillna(0.0)

    return result