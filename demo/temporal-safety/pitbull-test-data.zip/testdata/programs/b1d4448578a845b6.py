def get_features(db, entity_ids, seed_time):
    entity_ids = list(entity_ids)
    items = db['order_items']
    orders = db['orders']
    reviews = db['reviews']
    payments = db['payments']

    # Filter history (purchases strictly before seed_time)
    hist_mask = items['product_id'].isin(entity_ids) & (items['ts'] < seed_time)
    hist_items = items[hist_mask].copy()

    feature_columns = [
        'num_orders', 'num_items', 'sum_price', 'sum_sales', 'mean_price',
        'std_price', 'min_price', 'max_price', 'sum_freight', 'mean_freight',
        'mean_delivery_days', 'avg_review_score', 'count_reviews',
        'positive_review_ratio', 'avg_installments', 'avg_payment_value',
        'credit_card_ratio', 'recency', 'sales_30', 'sales_90'
    ]

    # No history -> all NaNs for every product
    if hist_items.empty:
        return pd.DataFrame(columns=feature_columns, index=entity_ids, dtype=float)

    # Get order ids that appear in the filtered items
    order_ids = hist_items['order_id'].unique()

    # --- Orders ---
    orders_sub = orders[orders['order_id'].isin(order_ids)].copy()
    orders_sub['delivery_time_days'] = (
        orders_sub['order_delivered_customer_date'] - orders_sub['order_purchase_timestamp']
    ).dt.total_seconds() / 86400.0

    # --- Reviews ---
    reviews_sub = reviews[reviews['order_id'].isin(order_ids)]
    if not reviews_sub.empty:
        review_agg = reviews_sub.groupby('order_id').agg(
            review_count=('review_score', 'count'),
            avg_review_score=('review_score', 'mean'),
            positive_review_ratio=('review_score', lambda x: (x >= 4).mean())
        ).reset_index()
    else:
        review_agg = pd.DataFrame({
            'order_id': order_ids,
            'review_count': 0,
            'avg_review_score': np.nan,
            'positive_review_ratio': np.nan
        })

    # --- Payments ---
    payments_sub = payments[payments['order_id'].isin(order_ids)]
    if not payments_sub.empty:
        payment_agg = payments_sub.groupby('order_id').agg(
            sum_payment=('payment_value', 'sum'),
            mean_payment=('payment_value', 'mean'),
            avg_inst=('payment_installments', 'mean'),
            credit_ratio=('payment_type', lambda x: (x == 'credit_card').mean())
        ).reset_index()
    else:
        payment_agg = pd.DataFrame({
            'order_id': order_ids,
            'sum_payment': 0,
            'mean_payment': 0,
            'avg_inst': 0,
            'credit_ratio': 0
        })

    # Merge order-level aggregates
    orders_agg = orders_sub.merge(review_agg, on='order_id', how='left')
    orders_agg = orders_agg.merge(payment_agg, on='order_id', how='left')

    # Attach order aggregates to items
    hist_items = hist_items.merge(orders_agg, on='order_id', how='left')

    # Total sales per item line, age in days since purchase
    hist_items['total'] = hist_items['price'] + hist_items['freight_value']
    hist_items['age'] = (seed_time - hist_items['ts']).dt.days

    # --- Group by product_id ---
    grouped = hist_items.groupby('product_id').agg(
        num_orders=('order_id', 'nunique'),
        num_items=('product_id', 'count'),
        sum_price=('price', 'sum'),
        sum_sales=('total', 'sum'),
        mean_price=('price', 'mean'),
        std_price=('price', 'std'),
        min_price=('price', 'min'),
        max_price=('price', 'max'),
        sum_freight=('freight_value', 'sum'),
        mean_freight=('freight_value', 'mean'),
        mean_delivery_days=('delivery_time_days', 'mean'),
        avg_review_score=('avg_review_score', 'mean'),
        count_reviews=('review_count', 'sum'),
        positive_review_ratio=('positive_review_ratio', 'mean'),
        avg_installments=('avg_inst', 'mean'),
        avg_payment_value=('mean_payment', 'mean'),
        credit_card_ratio=('credit_ratio', 'mean'),
        last_purchase=('ts', 'max'),
        sales_30=('age', lambda x: (x <= 30).sum()),
        sales_90=('age', lambda x: (x <= 90).sum())
    ).reset_index()

    # Recency
    grouped['recency'] = (seed_time - grouped['last_purchase']).dt.days
    grouped.drop(columns=['last_purchase'], inplace=True)

    # Reindex to exactly the requested entity_ids
    grouped = grouped.set_index('product_id').reindex(entity_ids)

    # Ensure all expected columns are present (in case some being missing)
    for c in feature_columns:
        if c not in grouped.columns:
            grouped[c] = np.nan

    return grouped[feature_columns]