import pandas as pd
import numpy as np

def get_features(db: dict, entity_ids, seed_time) -> pd.DataFrame:
    # Извлечение таблиц
    orders = db['orders']
    order_items = db['order_items']
    reviews = db['reviews']
    payments = db['payments']  # не используется в текущей версии, но доступна

    seed_time = pd.Timestamp(seed_time)

    # Заказы, совершённые до seed_time
    orders_before = orders[orders['order_purchase_timestamp'] < seed_time].copy()

    # Соединяем позиции с заказами (только до seed_time)
    items_hist = order_items.merge(
        orders_before[['order_id', 'order_purchase_timestamp', 'order_delivered_customer_date']],
        on='order_id',
        how='inner'
    )

    # Время доставки в днях (если есть)
    if 'order_delivered_customer_date' in items_hist.columns:
        items_hist['delivery_days'] = (
            items_hist['order_delivered_customer_date'] - items_hist['order_purchase_timestamp']
        ).dt.days
    else:
        items_hist['delivery_days'] = np.nan

    # Агрегаты по товарам
    agg = items_hist.groupby('product_id').agg(
        total_orders=('order_id', 'nunique'),
        total_quantity=('order_item_id', 'count'),
        total_sales=('price', 'sum'),
        avg_price=('price', 'mean'),
        std_price=('price', 'std'),
        total_freight=('freight_value', 'sum'),
        avg_freight=('freight_value', 'mean'),
        std_freight=('freight_value', 'std'),
        max_price=('price', 'max'),
        min_price=('price', 'min'),
        avg_delivery_days=('delivery_days', 'mean'),
        std_delivery_days=('delivery_days', 'std'),
    ).reset_index()

    # Давность последней покупки
    last_purchase = items_hist.groupby('product_id')['order_purchase_timestamp'].max().reset_index()
    last_purchase['days_since_last'] = (seed_time - last_purchase['order_purchase_timestamp']).dt.days
    last_purchase['days_since_last'] = last_purchase['days_since_last'].fillna(9999)
    agg = agg.merge(last_purchase[['product_id', 'days_since_last']], on='product_id', how='left')

    # Давность первого появления
    first_purchase = items_hist.groupby('product_id')['order_purchase_timestamp'].min().reset_index()
    first_purchase['days_since_first'] = (seed_time - first_purchase['order_purchase_timestamp']).dt.days
    first_purchase['days_since_first'] = first_purchase['days_since_first'].fillna(9999)
    agg = agg.merge(first_purchase[['product_id', 'days_since_first']], on='product_id', how='left')

    # Оконные признаки (30, 60, 90 дней)
    for window in [30, 60, 90]:
        cutoff = seed_time - pd.Timedelta(days=window)
        mask = items_hist['order_purchase_timestamp'] >= cutoff
        window_items = items_hist[mask]
        window_agg = window_items.groupby('product_id').agg(
            **{f'orders_last_{window}': ('order_id', 'nunique'),
               f'sales_last_{window}': ('price', 'sum')}
        ).reset_index()
        agg = agg.merge(window_agg, on='product_id', how='left')

    # Признаки на основе отзывов
    items_reviews = items_hist[['order_id', 'product_id']].merge(
        reviews[['order_id', 'review_score']], on='order_id', how='left'
    )
    reviews_agg = items_reviews.groupby('product_id').agg(
        review_count=('review_score', 'count'),
        avg_review_score=('review_score', 'mean'),
        std_review_score=('review_score', 'std'),
        pos_review_count=('review_score', lambda x: (x >= 4).sum())
    ).reset_index()
    reviews_agg['pos_review_ratio'] = reviews_agg['pos_review_count'] / reviews_agg['review_count'].replace(0, np.nan)
    reviews_agg['pos_review_ratio'] = reviews_agg['pos_review_ratio'].fillna(0)
    agg = agg.merge(reviews_agg, on='product_id', how='left')

    # Признаки по продавцам
    sellers_agg = items_hist.groupby('product_id').agg(
        unique_sellers=('seller_id', 'nunique')
    ).reset_index()
    agg = agg.merge(sellers_agg, on='product_id', how='left')

    # Дополнительные признаки интенсивности продаж
    # Продажи в день с момента первого появления (защита от деления на 0)
    agg['sales_per_day_since_first'] = agg['total_sales'] / (agg['days_since_first'] + 1)
    agg['orders_per_day_since_first'] = agg['total_orders'] / (agg['days_since_first'] + 1)

    # Устанавливаем индекс и реиндексируем
    agg = agg.set_index('product_id')
    agg = agg.reindex(entity_ids).fillna(0)

    return agg