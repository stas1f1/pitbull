import pandas as pd
import numpy as np

def get_features(db: dict, entity_ids, seed_time) -> pd.DataFrame:
    """
    Возвращает матрицу признаков для каждого product_id на основе истории до seed_time.
    """
    orders = db['orders']
    items = db['order_items']
    payments = db['payments']
    reviews = db['reviews']
    
    seed_time = pd.Timestamp(seed_time)
    
    # Только заказы, совершённые строго до seed_time
    orders_before = orders[orders['order_purchase_timestamp'] < seed_time].copy()
    
    # Если нет заказов до seed_time, вернуть нули
    if orders_before.empty:
        feature_cols = [
            'order_count', 'total_revenue', 'avg_price', 'median_price', 'std_price',
            'unique_sellers', 'days_since_last_purchase', 'product_age_days',
            'avg_freight', 'avg_installments', 'avg_delivery_days',
            'avg_estimated_delivery_days', 'avg_review_score'
        ]
        return pd.DataFrame(0, index=entity_ids, columns=feature_cols)
    
    # Соединяем items с заказами
    merged = items.merge(
        orders_before[['order_id', 'order_purchase_timestamp', 'order_delivered_customer_date',
                       'order_estimated_delivery_date']],
        on='order_id',
        how='inner'
    )
    
    if merged.empty:
        feature_cols = [
            'order_count', 'total_revenue', 'avg_price', 'median_price', 'std_price',
            'unique_sellers', 'days_since_last_purchase', 'product_age_days',
            'avg_freight', 'avg_installments', 'avg_delivery_days',
            'avg_estimated_delivery_days', 'avg_review_score'
        ]
        return pd.DataFrame(0, index=entity_ids, columns=feature_cols)
    
    # Агрегация по товарам
    grp = merged.groupby('product_id')
    
    # Основные агрегаты
    features = pd.DataFrame()
    features['order_count'] = grp.size()
    features['total_revenue'] = grp.apply(lambda x: (x['price'] + x['freight_value']).sum())
    features['avg_price'] = grp['price'].mean()
    features['median_price'] = grp['price'].median()
    features['std_price'] = grp['price'].std()
    features['unique_sellers'] = grp['seller_id'].nunique()
    features['avg_freight'] = grp['freight_value'].mean()
    
    # Время последней и первой покупки
    last_purchase = grp['order_purchase_timestamp'].max()
    first_purchase = grp['order_purchase_timestamp'].min()
    features['days_since_last_purchase'] = (seed_time - last_purchase).dt.days
    features['product_age_days'] = (seed_time - first_purchase).dt.days
    
    # Среднее время доставки и оценки
    def avg_delivery_days(x):
        return (x['order_delivered_customer_date'] - x['order_purchase_timestamp']).dt.days.mean()
    features['avg_delivery_days'] = grp.apply(avg_delivery_days)
    
    def avg_est_delivery_days(x):
        return (x['order_estimated_delivery_date'] - x['order_purchase_timestamp']).dt.days.mean()
    features['avg_estimated_delivery_days'] = grp.apply(avg_est_delivery_days)
    
    # Признаки из платежей (среднее количество платежей в рассрочку)
    # Сначала берём уникальные заказы, чтобы не дублировать
    order_pay = payments.groupby('order_id')['payment_installments'].mean().rename('avg_installments')
    merged_pay = merged[['order_id', 'product_id']].drop_duplicates().merge(order_pay, on='order_id', how='left')
    pay_agg = merged_pay.groupby('product_id')['avg_installments'].mean()
    features['avg_installments'] = pay_agg
    
    # Средний рейтинг отзывов
    order_rev = reviews.groupby('order_id')['review_score'].mean().rename('review_score')
    merged_rev = merged[['order_id', 'product_id']].drop_duplicates().merge(order_rev, on='order_id', how='left')
    rev_agg = merged_rev.groupby('product_id')['review_score'].mean()
    features['avg_review_score'] = rev_agg
    
    # Убираем возможные дубликаты индексов
    features = features[~features.index.duplicated(keep='first')]
    
    # Реиндексация по entity_ids
    features = features.reindex(entity_ids)
    features = features.fillna(0)
    
    return features