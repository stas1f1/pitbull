def get_features(db: dict, entity_ids, seed_time) -> pd.DataFrame:
    orders = db["orders"].copy()
    order_items = db["order_items"].copy()
    reviews = db["reviews"].copy()
    payments = db["payments"].copy()

    # Convert seed_time to datetime if needed
    if not isinstance(seed_time, pd.Timestamp):
        seed_time = pd.Timestamp(seed_time)

    # For each product, we need features up to seed_time
    # Basic order information: use only orders placed before seed_time
    # We can join order_items with orders on order_id to get product purchases
    items_orders = order_items.merge(orders[['order_id', 'order_purchase_timestamp', 'order_status', 'order_approved_at', 'order_delivered_customer_date']], on='order_id', how='left')

    # Filter orders before seed_time (purchase timestamp)
    items_before = items_orders[items_orders['order_purchase_timestamp'] < seed_time]

    # We only need rows for the products of interest
    items_before = items_before[items_before['product_id'].isin(entity_ids)]

    # Aggregate features per product
    features = pd.DataFrame(index=entity_ids)

    # 1. Number of purchases (total items) in the last 30, 60, 90, 180 days before seed_time
    items_before['ts'] = items_before['order_purchase_timestamp']
    for window in [30, 60, 90, 180]:
        cutoff = seed_time - pd.Timedelta(days=window)
        temp = items_before[items_before['order_purchase_timestamp'] >= cutoff]
        counts = temp.groupby('product_id').size().rename(f'sales_last_{window}d')
        features = pd.DataFrame(index=entity_ids)
        features[f'sales_last_{window}d'] = counts.reindex(entity_ids).fillna(0)
        if 'features' in locals() or 'features' in dir():
            features = features  # just to avoid, but will combine below
        # Actually just reassign or keep dict
        if 'feature_frame' not in locals():
            feature_frame = features
        else:
            feature_frame = feature_frame.join(features)

    # 2. Total quantity sold (actually number of items) and total revenue (sum of price + freight) up to seed_time
    features_temp = pd.DataFrame(index=entity_ids)
    if len(items_before) > 0:
        temp_sum = items_before.groupby('product_id').agg(
            total_sold=('order_item_id', 'count'),
            total_revenue=('price', 'sum'),
            avg_price=('price', 'mean'),
            total_freight=('freight_value', 'sum'),
            avg_freight=('freight_value', 'mean')
        )
        features_temp['total_sold'] = temp_sum['total_sold'].reindex(entity_ids).fillna(0)
        features_temp['total_revenue'] = temp_sum['total_revenue'].reindex(entity_ids).fillna(0)
        features_temp['avg_price'] = temp_sum['avg_price'].reindex(entity_ids).fillna(0)
        features_temp['total_freight'] = temp_sum['total_freight'].reindex(entity_ids).fillna(0)
        features_temp['avg_freight'] = temp_sum['avg_freight'].reindex(entity_ids).fillna(0)
    else:
        features_temp = pd.DataFrame(0, index=entity_ids, columns=['total_sold','total_revenue','avg_price','total_freight','avg_freight'])

    # Start assembling feature frame
    feature_frame = features_temp.copy()

    # 3. Number of distinct sellers selling this product (ever before seed_time)
    sellers = items_before.groupby('product_id')['seller_id'].nunique().rename('distinct_sellers')
    feature_frame['distinct_sellers'] = sellers.reindex(entity_ids).fillna(0)

    # 4. Number of distinct orders containing the product (split by order)
    distinct_orders = items_before.groupby('product_id')['order_id'].nunique().rename('distinct_orders')
    feature_frame['distinct_orders'] = distinct_orders.reindex(entity_ids).fillna(0)

    # 5. Average review score for orders containing this product (up to seed_time? Reviews after purchase but we can consider all reviews associated with those orders, no time cutoff)
    # Orders that have product
    prod_orders = items_before[['product_id', 'order_id']].drop_duplicates()
    rev_merged = prod_orders.merge(reviews[['order_id', 'review_score']], on='order_id', how='left')
    avg_review = rev_merged.groupby('product_id')['review_score'].mean().rename('avg_review_score')
    feature_frame['avg_review_score'] = avg_review.reindex(entity_ids).fillna(0)

    # 6. Number of reviews for product's orders
    rev_count = rev_merged.groupby('product_id')['review_score'].count().rename('review_count')
    feature_frame['review_count'] = rev_count.reindex(entity_ids).fillna(0)

    # 7. Payment info: average installment count, average payment value per product (from orders that contain product)
    # Use payments table
    pay_orders = prod_orders.merge(payments[['order_id','payment_installments','payment_value']], on='order_id', how='left')
    if len(pay_orders) > 0:
        pay_agg = pay_orders.groupby('product_id').agg(
            avg_installments=('payment_installments', 'mean'),
            avg_payment_value=('payment_value', 'mean'),
            total_payment_value=('payment_value', 'sum')
        )
        feature_frame['avg_installments'] = pay_agg['avg_installments'].reindex(entity_ids).fillna(0)
        feature_frame['avg_payment_value'] = pay_agg['avg_payment_value'].reindex(entity_ids).fillna(0)
        feature_frame['total_payment_value'] = pay_agg['total_payment_value'].reindex(entity_ids).fillna(0)
    else:
        feature_frame['avg_installments'] = 0
        feature_frame['avg_payment_value'] = 0
        feature_frame['total_payment_value'] = 0

    # 8. Time since first purchase of this product (in days) up to seed_time
    if len(items_before) > 0:
        first_purchase = items_before.groupby('product_id')['order_purchase_timestamp'].min().rename('first_purchase_ts')
        feature_frame['first_purchase_ts'] = first_purchase.reindex(entity_ids)
        feature_frame['days_since_first_purchase'] = (seed_time - feature_frame['first_purchase_ts']).dt.days.fillna(seed_time.toordinal())
    else:
        feature_frame['days_since_first_purchase'] = 0

    # 9. Recency: how many days since last purchase (for product) up to seed_time
    if len(items_before) > 0:
        last_purchase = items_before.groupby('product_id')['order_purchase_timestamp'].max().rename('last_purchase_ts')
        feature_frame['last_purchase_ts'] = last_purchase.reindex(entity_ids)
        feature_frame['days_since_last_purchase'] = (seed_time - feature_frame['last_purchase_ts']).fillna(pd.Timedelta(days=0)).dt.days
    else:
        feature_frame['days_since_last_purchase'] = 0

    # Drop helper columns
    drop_cols = ['first_purchase_ts', 'last_purchase_ts']
    if 'first_purchase_ts' in feature_frame.columns:
        feature_frame = feature_frame.drop(columns=drop_cols, errors='ignore')

    # 10. Time of day: average hour of purchase? Probably not using, but we can add
    # 11. Number of months since first purchase
    # 12. Number of orders with product that were delivered on time? We can compute
    # Ensure all columns numeric, fill any remaining NaNs with 0
    feature_frame = feature_frame.fillna(0)

    # Reindex to entity_ids and return
    feature_frame = feature_frame.loc[entity_ids]
    return feature_frame