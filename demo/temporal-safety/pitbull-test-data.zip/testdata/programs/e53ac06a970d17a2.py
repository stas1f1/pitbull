import pandas as pd
import numpy as np

def get_features(db, entity_ids, seed_time):
    # Приведём entity_ids к списку, чтобы работать с pandas
    if isinstance(entity_ids, (list, np.ndarray, pd.Series)):
        product_ids = list(entity_ids)
    else:
        product_ids = [entity_ids]

    # --- Таблицы из БД ---
    orders = db["orders"]
    items = db["order_items"]
    reviews = db["reviews"]
    payments = db["payments"]

    # Отбираем позиции по интересующим продуктам
    items_filtered = items[items["product_id"].isin(product_ids)].copy()

    # Присоединяем заказы (нам нужны колонки с временными метками и статусом)
    merged = items_filtered.merge(orders[["order_id", "order_status", 
                                          "order_delivered_customer_date"]],
                                 on="order_id", how="left")

    # Фильтруем по времени покупки (ts)
    merged = merged[merged["ts"] < seed_time]

    # ---- Агрегаты для платежей по заказам ----
    pay_agg = payments.groupby("order_id").agg(
        total_payment=("payment_value", "sum"),
        count_payments=("payment_value", "count"),
        avg_installments=("payment_installments", "mean")
    ).reset_index()

    # ---- Агрегаты для отзывов по заказам ----
    rev_temp = reviews.copy()
    rev_temp["positive"] = (rev_temp["review_score"] >= 4).astype(int)
    rev_agg = rev_temp.groupby("order_id").agg(
        avg_review=("review_score", "mean"),
        count_reviews=("review_score", "count"),
        positive_count=("positive", "sum")
    ).reset_index()
    rev_agg["positive_ratio"] = rev_agg["positive_count"] / rev_agg["count_reviews"]

    # ---- Присоединяем агрегаты к основной таблице ----
    merged = merged.merge(pay_agg, on="order_id", how="left")
    merged = merged.merge(rev_agg, on="order_id", how="left")

    # Возможное время доставки в днях (если есть)
    merged["delivery_days"] = (merged["order_delivered_customer_date"] - merged["ts"]).dt.days

    # ============================================================
    # Признаки, считаемые по позициям (строкам item)
    # ============================================================
    pos_agg = merged.groupby("product_id").agg(
        total_items=("price", "count"),
        total_price=("price", "sum"),
        total_freight=("freight_value", "sum"),
        avg_price=("price", "mean"),
        std_price=("price", "std"),
        min_price=("price", "min"),
        max_price=("price", "max"),
        avg_freight=("freight_value", "mean"),
        std_freight=("freight_value", "std"),
        avg_delivery_days=("delivery_days", "mean")
    ).reset_index()

    # ============================================================
    # Признаки по уникальным заказам для каждого продукта
    # ============================================================
    # Убираем дубли (один и тот же продукт в одном заказе встречается несколько раз)
    order_level = merged[["product_id", "order_id", "ts",
                          "total_payment", "count_payments", "avg_installments",
                          "avg_review", "count_reviews", "positive_ratio"]].drop_duplicates(
                              subset=["product_id", "order_id"])

    # Группируем по продукту
    order_agg = order_level.groupby("product_id").agg(
        num_orders=("order_id", "nunique"),
        total_payment_all=("total_payment", "sum"),
        avg_payment_per_order=("total_payment", "mean"),
        std_payment_per_order=("total_payment", "std"),
        avg_payments_per_order=("count_payments", "mean"),
        avg_install_mean=("avg_installments", "mean"),
        avg_review_score=("avg_review", "mean"),
        avg_review_count=("count_reviews", "mean"),
        avg_positive_ratio=("positive_ratio", "mean")
    ).reset_index()

    # Временные признаки
    order_level["last_date"] = order_level.groupby("product_id")["ts"].transform("max")
    order_level["first_date"] = order_level.groupby("product_id")["ts"].transform("min")

    temp_agg = order_level.groupby("product_id").agg(
        days_since_last=("ts", lambda x: (seed_time - x.max()).days),
        days_since_first=("ts", lambda x: (seed_time - x.min()).days),
        date_span=("ts", lambda x: (x.max() - x.min()).days)  # может быть 0, если одна покупка
    ).reset_index()

    # В temp_agg могут получиться NaN, если нет заказов — заменим на 0
    # объединяем все признаки по продуктам
    features = pos_agg.merge(order_agg, on="product_id", how="outer")
    features = features.merge(temp_agg, on="product_id", how="outer")

    # Устанавливаем индекс product_id
    features = features.set_index("product_id")

    # Создаём пустой DataFrame для всех требуемых продуктов
    result = pd.DataFrame(index=product_ids)

    # Присоединяем вычисленные признаки (не все столбцы)
    result = result.join(features, how="left")

    # Добавляем признак, есть ли продажи вообще
    result["has_sales"] = result["num_orders"].notna().astype(int)

    # Заполняем отсутствующие значения нулями (для отсутствия истории)
    result = result.fillna(0)

    # Убедимся, что только числовые столбцы (не критично, но для безопасности)
    result = result.astype(float)

    # Возвращаем результат с реиндексацией под entity_ids
    result = result.loc[product_ids]
    return result