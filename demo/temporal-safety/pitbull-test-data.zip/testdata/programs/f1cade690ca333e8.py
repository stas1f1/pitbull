def get_features(db: dict, entity_ids, seed_time) -> pd.DataFrame:
    # расчленяем исходные данные
    orders = db["orders"]
    order_items = db["order_items"]
    reviews = db["reviews"]
    payments = db["payments"]

    # Фильтруем исторические заказы: только до seed_time и только нужные товары
    product_set = set(entity_ids)
    mask = order_items["product_id"].isin(product_set) & (order_items["ts"] < seed_time)
    items = order_items.loc[mask, ["order_id", "product_id", "seller_id", "price", "freight_value", "ts"]].copy()

    # Если истории для интересующих товаров не оказалось
    if items.empty:
        result = pd.DataFrame(index=entity_ids)
        # создадим пустые признаки с нулями (все типы числовые)
        # количество признаков здесь резервируем как в основной ветке
        sample_features = [
            "order_count", "unique_orders", "unique_customers", "unique_sellers",
            "total_price", "avg_price", "std_price", "max_price", "min_price",
            "total_freight", "avg_freight",
            "cnt_30", "cnt_60", "cnt_90",
            "canceled_share", "delivered_share",
            "avg_review", "std_review", "total_reviews",
            "avg_installments", "avg_payment_value",
            "credit_share", "debit_share", "voucher_share",
            "last_purchase_days", "first_purchase_days", "avg_daily_orders",
        ]
        for c in sample_features:
            result[c] = 0.0
        return result

    # присоединяем информацию о заказе (customer_id, статус)
    orders_sub = orders[["order_id", "customer_id", "order_status"]]
    items = items.merge(orders_sub, on="order_id", how="left")

    # Агрегируем платежи по заказу
    pay_agg = payments.groupby("order_id").agg(
        install_mean=("payment_installments", "mean"),
        total_pay=("payment_value", "sum"),
        credit_share=("payment_type", lambda s: (s == "credit_card").mean()),
        debit_share=("payment_type", lambda s: (s == "debit_card").mean()),
        voucher_share=("payment_type", lambda s: (s == "voucher").mean()),
    )

    # Агрегируем отзывы по заказу
    rev_agg = reviews.groupby("order_id").agg(
        rev_count=("review_id", "count"),
        rev_avg=("review_score", "mean"),
        rev_std=("review_score", "std"),
    )

    items = items.merge(pay_agg, on="order_id", how="left")
    items = items.merge(rev_agg, on="order_id", how="left")

    # Вспомогательные флаги
    items["cnt_30"] = (items["ts"] >= seed_time - pd.Timedelta(days=30)).astype(int)
    items["cnt_60"] = (items["ts"] >= seed_time - pd.Timedelta(days=60)).astype(int)
    items["cnt_90"] = (items["ts"] >= seed_time - pd.Timedelta(days=90)).astype(int)
    items["is_canceled"] = (items["order_status"] == "canceled").astype(int)
    items["is_delivered"] = (items["order_status"] == "delivered").astype(int)

    # Главная группировка по товару
    g = items.groupby("product_id")
    feat = g.agg(
        order_count=("order_id", "count"),
        unique_orders=("order_id", "nunique"),
        unique_customers=("customer_id", "nunique"),
        unique_sellers=("seller_id", "nunique"),
        total_price=("price", "sum"),
        avg_price=("price", "mean"),
        std_price=("price", "std"),
        max_price=("price", "max"),
        min_price=("price", "min"),
        total_freight=("freight_value", "sum"),
        avg_freight=("freight_value", "mean"),
        cnt_30=("cnt_30", "sum"),
        cnt_60=("cnt_60", "sum"),
        cnt_90=("cnt_90", "sum"),
        canceled_share=("is_canceled", "mean"),
        delivered_share=("is_delivered", "mean"),
        avg_review=("rev_avg", "mean"),
        std_review=("rev_std", "mean"),
        total_reviews=("rev_count", "sum"),
        avg_installments=("install_mean", "mean"),
        avg_payment_value=("total_pay", "mean"),
        credit_share=("credit_share", "mean"),
        debit_share=("debit_share", "mean"),
        voucher_share=("voucher_share", "mean"),
        max_ts=("ts", "max"),
        min_ts=("ts", "min"),
    )

    # Временные признаки: давность последней и первой покупки
    last_purchase_days = (seed_time - feat["max_ts"]) / pd.Timedelta(days=1)
    first_purchase_days = (seed_time - feat["min_ts"]) / pd.Timedelta(days=1)

    feat["last_purchase_days"] = last_purchase_days
    feat["first_purchase_days"] = first_purchase_days
    feat["avg_daily_orders"] = feat["order_count"] / first_purchase_days.clip(lower=1)

    # Убираем временные вспомогательные колонки
    feat = feat.drop(columns=["max_ts", "min_ts"])

    # Связываем с запрошенными id (для отсутствующих товаров — значения по умолчанию)
    result = pd.DataFrame(index=entity_ids)
    result = result.join(feat, how="left")
    result = result.fillna(0.0)

    # Убеждаемся, что индексы в том же порядке, как просили
    result = result.reindex(entity_ids)
    return result