import pandas as pd
import numpy as np

def get_features(db, entity_ids, seed_time):
    # Извлекаем таблицы
    orders = db['orders'].copy()
    items = db['order_items'].copy()
    reviews = db['reviews'].copy()
    payments = db['payments'].copy()
    
    # Приводим seed_time к Timestamp
    if not isinstance(seed_time, pd.Timestamp):
        seed_time = pd.Timestamp(seed_time)
    
    # Фильтруем заказы до seed_time
    orders = orders[orders['order_purchase_timestamp'] <= seed_time]
    
    # Соединяем items с заказами
    df = items.merge(orders[['order_id', 'order_purchase_timestamp', 'order_delivered_customer_date', 'order_estimated_delivery_date']],
                     on='order_id', how='inner')
    
    # Вычисляем дни доставки (если есть)
    df['delivery_days'] = (df['order_delivered_customer_date'] - df['order_purchase_timestamp']).dt.days
    
    # Просрочка доставки
    df['late'] = (df['order_delivered_customer_date'] > df['order_estimated_delivery_date']).astype(float)
    
    # Дни с момента покупки до seed_time
    df['days_since_purchase'] = (seed_time - df['order_purchase_timestamp']).dt.days
    
    # Индикаторы окон
    df['last_7'] = (df['days_since_purchase'] <= 7).astype(int)
    df['last_30'] = (df['days_since_purchase'] <= 30).astype(int)
    df['last_90'] = (df['days_since_purchase'] <= 90).astype(int)
    
    # Агрегация по product_id (основные признаки)
    grouped = df.groupby('product_id').agg(
        num_orders=('order_id', 'nunique'),
        num_items=('order_id', 'size'),
        total_price=('price', 'sum'),
        avg_price=('price', 'mean'),
        median_price=('price', 'median'),
        std_price=('price', 'std'),
        total_freight=('freight_value', 'sum'),
        avg_freight=('freight_value', 'mean'),
        avg_delivery_days=('delivery_days', 'mean'),
        min_delivery_days=('delivery_days', 'min'),
        max_delivery_days=('delivery_days', 'max'),
        late_delivery_rate=('late', 'mean'),
        days_since_last_order=('days_since_purchase', 'min'),
        days_since_first_order=('days_since_purchase', 'max'),
        last_7_orders=('last_7', 'sum'),
        last_30_orders=('last_30', 'sum'),
        last_90_orders=('last_90', 'sum'),
    ).reset_index()
    
    # Частота заказов
    grouped['order_frequency'] = grouped['num_orders'] / (grouped['days_since_first_order'] + 1)
    
    # Обработка отзывов
    review_agg = reviews.groupby('order_id').agg(
        avg_review_score=('review_score', 'mean'),
        num_reviews=('review_score', 'size')
    ).reset_index()
    
    df = df.merge(review_agg, on='order_id', how='left')
    
    unique_reviews = df[['product_id', 'order_id', 'avg_review_score']].drop_duplicates(subset=['product_id', 'order_id'])
    review_prod = unique_reviews.groupby('product_id').agg(
        avg_review_score=('avg_review_score', 'mean'),
        num_reviews=('order_id', 'count')
    ).reset_index()
    
    # Обработка платежей
    pay_agg = payments.groupby('order_id').agg(
        total_payment=('payment_value', 'sum'),
        num_payments=('payment_sequential', 'count')
    ).reset_index()
    
    df = df.merge(pay_agg, on='order_id', how='left')
    
    unique_pay = df[['product_id', 'order_id', 'total_payment', 'num_payments']].drop_duplicates(subset=['product_id', 'order_id'])
    pay_prod = unique_pay.groupby('product_id').agg(
        avg_payment_value=('total_payment', 'mean'),
        avg_num_payments=('num_payments', 'mean'),
        total_payment_sum=('total_payment', 'sum')
    ).reset_index()
    
    # Объединяем все признаки
    features = grouped.merge(review_prod, on='product_id', how='left')
    features = features.merge(pay_prod, on='product_id', how='left')
    
    # Устанавливаем индекс
    features.set_index('product_id', inplace=True)
    
    # Реиндексируем по entity_ids и заполняем пропуски нулями
    features = features.reindex(entity_ids).fillna(0)
    
    return features