def get_features(db: dict, entity_ids, seed_time) -> pd.DataFrame:
    # Извлекаем таблицы
    orders = db['orders']
    order_items = db['order_items']
    reviews = db['reviews']
    payments = db['payments']

    # Фильтруем заказы до seed_time
    orders = orders[orders['order_purchase_timestamp'] < seed_time].copy()

    # Признак доставки вовремя (если обе даты есть)
    orders['delivered_on_time'] = (
        (orders['order_delivered_customer_date'] <= orders['order_estimated_delivery_date'])
        .astype(int)
    )

    # Агрегация платежей по заказам
    payments_agg = payments.groupby('order_id').agg(
        payment_value_sum=('payment_value', 'sum'),
        payment_installments_mean=('payment_installments', 'mean'),
        payment_count=('payment_value', 'count')
    ).reset_index()

    # One-hot для типов платежей
    payment_type_counts = payments.groupby(['order_id', 'payment_type']).size().unstack(fill_value=0)
    payment_type_counts.columns = ['payment_type_' + col for col in payment_type_counts.columns]
    payments_agg = payments_agg.merge(payment_type_counts, on='order_id', how='left')

    # Агрегация отзывов по заказам
    reviews_agg = reviews.groupby('order_id').agg(
        review_score_mean=('review_score', 'mean'),
        review_count=('review_score', 'count')
    ).reset_index()

    # Объединяем order_items с заказами и агрегатами
    order_items = order_items.merge(
        orders[['order_id', 'order_purchase_timestamp', 'delivered_on_time']],
        on='order_id',
        how='inner'
    )
    order_items = order_items.merge(payments_agg, on='order_id', how='left')
    order_items = order_items.merge(reviews_agg, on='order_id', how='left')

    # Оставляем только нужные продукты
    order_items = order_items[order_items['product_id'].isin(entity_ids)]

    # Группировка по продукту
    grouped = order_items.groupby('product_id')

    # Инициализируем DataFrame с индексом entity_ids
    features = pd.DataFrame(index=entity_ids)

    # Основные агрегаты
    features['total_orders'] = grouped.size()
    features['total_unique_orders'] = grouped['order_id'].nunique()
    features['sum_price'] = grouped['price'].sum()
    features['mean_price'] = grouped['price'].mean()
    features['std_price'] = grouped['price'].std()
    features['sum_freight'] = grouped['freight_value'].sum()
    features['mean_freight'] = grouped['freight_value'].mean()
    features['std_freight'] = grouped['freight_value'].std()
    features['unique_sellers'] = grouped['seller_id'].nunique()

    # Временные признаки
    # Последняя покупка
    last_purchase = grouped['order_purchase_timestamp'].max()
    features['days_since_last_purchase'] = (seed_time - last_purchase).dt.days

    # Средний интервал между покупками
    order_items_sorted = order_items.sort_values(['product_id', 'order_purchase_timestamp'])
    order_items_sorted['prev_time'] = order_items_sorted.groupby('product_id')['order_purchase_timestamp'].shift()
    order_items_sorted['diff_days'] = (order_items_sorted['order_purchase_timestamp'] - order_items_sorted['prev_time']).dt.days
    avg_diff = order_items_sorted.groupby('product_id')['diff_days'].mean()
    features['avg_days_between_purchases'] = avg_diff

    # Окна 30/60/90 дней
    for window in [30, 60, 90]:
        cutoff = seed_time - pd.Timedelta(days=window)
        recent = order_items[order_items['order_purchase_timestamp'] >= cutoff]
        recent_counts = recent.groupby('product_id').size()
        features[f'orders_last_{window}d'] = recent_counts
        recent_price = recent.groupby('product_id')['price'].sum()
        features[f'price_sum_last_{window}d'] = recent_price

    # Отзывы
    features['review_score_mean'] = grouped['review_score_mean'].mean()
    features['review_count'] = grouped['review_count'].sum()
    features['review_rate'] = features['review_count'] / features['total_orders']

    # Платежи
    features['payment_value_sum'] = grouped['payment_value_sum'].sum()
    features['payment_installments_mean'] = grouped['payment_installments_mean'].mean()
    features['payment_count'] = grouped['payment_count'].sum()

    # One-hot типов платежей
    for col in payment_type_counts.columns:
        if col in order_items.columns:
            features[col] = grouped[col].sum()

    # Доставка
    features['delivered_on_time_ratio'] = grouped['delivered_on_time'].mean()

    # Заполняем пропуски (для продуктов без истории) нулями
    features = features.fillna(0)

    return features