def get_features(db: dict, entity_ids, seed_time) -> pd.DataFrame:
    # Helper function to compute aggregate features for a time window
    def get_agg_features(df, mask, suffix):
        filtered = df[mask]
        agg = filtered.groupby('product_id').agg(
            # Sales metrics
            units_sold=('order_item_id', 'count'),
            num_orders=('order_id', 'nunique'),
            total_revenue=('price', 'sum'),
            total_freight=('freight_value', 'sum'),
            avg_price=('price', 'mean'),
            avg_freight=('freight_value', 'mean'),
            # Order success metrics
            num_successful_orders=('order_id', lambda x: filtered.loc[x.index, 'order_id'][filtered.loc[x.index, 'is_successful']].nunique()),
            num_failed_orders=('order_id', lambda x: filtered.loc[x.index, 'order_id'][filtered.loc[x.index, 'is_failed']].nunique()),
            # Delivery metrics
            avg_delivery_delay=('delivery_delay_days', lambda x: x.dropna().mean()),
            # Payment metrics
            avg_total_payment=('total_payment', 'mean'),
            avg_installments=('avg_payment_installments', 'mean'),
            pct_credit_card=('has_credit_card', lambda x: x.sum() / x.count() if x.count() > 0 else 0),
            pct_boleto=('has_boleto', lambda x: x.sum() / x.count() if x.count() > 0 else 0),
            # Review metrics
            avg_review_score=('avg_review_score', lambda x: x.dropna().mean()),
            num_reviews=('num_reviews', 'sum'),
            share_positive_reviews=('share_positive', lambda x: x.dropna().mean())
        )
        agg.columns = [f"{col}_{suffix}" for col in agg.columns]
        return agg
    # Create base DataFrame with all requested product IDs
    base = pd.DataFrame(index=entity_ids)
    base.index.name = 'product_id'
    # Pre-aggregate payments to order level (handle split payments)
    order_payments = db['payments'].groupby('order_id').agg(
        total_payment=('payment_value', 'sum'),
        avg_payment_installments=('payment_installments', 'mean'),
        has_credit_card=('payment_type', lambda x: 1 if 'credit_card' in x.values else 0),
        has_boleto=('payment_type', lambda x: 1 if 'boleto' in x.values else 0)
    ).reset_index()
    # Pre-aggregate reviews to order level
    order_reviews = db['reviews'].groupby('order_id').agg(
        avg_review_score=('review_score', 'mean'),
        num_reviews=('review_id', 'count'),
        share_positive=('review_score', lambda x: (x >= 4).sum() / len(x) if len(x) > 0 else 0)
    ).reset_index()
    # Filter relevant order items (target products, past purchases only)
    relevant_items = db['order_items'][
        db['order_items']['product_id'].isin(entity_ids) &
        (db['order_items']['ts'] < seed_time)
    ].copy()
    # Merge with orders, payments, and reviews data
    items_full = relevant_items.merge(
        db['orders'][['order_id', 'order_status', 'order_delivered_customer_date', 'order_estimated_delivery_date']],
        on='order_id', how='left'
    ).merge(
        order_payments, on='order_id', how='left'
    ).merge(
        order_reviews, on='order_id', how='left'
    )
    # Add derived columns for easier aggregation
    if not items_full.empty:
        items_full['days_before_seed'] = (seed_time - items_full['ts']).dt.days
        items_full['window'] = pd.cut(
            items_full['days_before_seed'],
            bins=[-1, 90, 180, 360, float('inf')],
            labels=['w1', 'w2', 'w3', 'older']
        )
        items_full['is_successful'] = ~items_full['order_status'].isin(['canceled', 'unavailable'])
        items_full['is_failed'] = items_full['order_status'].isin(['canceled', 'unavailable'])
        items_full['delivery_delay_days'] = (
            items_full['order_delivered_customer_date'] - items_full['order_estimated_delivery_date']
        ).dt.days
    # Compute aggregates for each time window
    if not items_full.empty:
        agg_w1 = get_agg_features(items_full, items_full['window'] == 'w1', 'w1')
        agg_w2 = get_agg_features(items_full, items_full['window'] == 'w2', 'w2')
        agg_w3 = get_agg_features(items_full, items_full['window'] == 'w3', 'w3')
        agg_older = get_agg_features(items_full, items_full['window'] == 'older', 'older')
        # Compute global product history and recency
        prod_history = items_full.groupby('product_id').agg(
            last_purchase_ts=('ts', 'max'),
            total_units_history=('order_item_id', 'count'),
            total_revenue_history=('price', 'sum'),
            avg_review_score_history=('avg_review_score', lambda x: x.dropna().mean()),
            total_reviews_history=('num_reviews', 'sum')
        ).reset_index()
        prod_history['days_since_last_purchase'] = (seed_time - prod_history['last_purchase_ts']).dt.days
        prod_history = prod_history.drop(columns=['last_purchase_ts'])
        prod_history = prod_history.set_index('product_id')
    else:
        # Create empty aggregates if no historical data
        agg_w1 = pd.DataFrame()
        agg_w2 = pd.DataFrame()
        agg_w3 = pd.DataFrame()
        agg_older = pd.DataFrame()
        prod_history = pd.DataFrame(
            columns=['total_units_history', 'total_revenue_history', 'avg_review_score_history',
                     'total_reviews_history', 'days_since_last_purchase'],
            index=base.index
        )
        prod_history.index.name = 'product_id'
    # Merge all features into base DataFrame
    features = base.join(agg_w1, how='left')
    features = features.join(agg_w2, how='left')
    features = features.join(agg_w3, how='left')
    features = features.join(agg_older, how='left')
    features = features.join(prod_history, how='left')
    # Add history flag and handle missing values
    features['has_history'] = (~features['total_units_history'].isna()).astype(int)
    # Fill all numeric columns with 0 first
    numeric_cols = features.select_dtypes(include=[np.number]).columns.tolist()
    features[numeric_cols] = features[numeric_cols].fillna(0)
    # Correct recency for products with no history
    features.loc[features['has_history'] == 0, 'days_since_last_purchase'] = 9999
    # Add derived trend and ratio features
    # Growth rates between windows
    features['units_growth_w1_w2'] = (features['units_sold_w1'] - features['units_sold_w2']) / (features['units_sold_w2'] + 1e-6)
    features['revenue_growth_w1_w2'] = (features['total_revenue_w1'] - features['total_revenue_w2']) / (features['total_revenue_w2'] + 1e-6)
    features['units_growth_w2_w3'] = (features['units_sold_w2'] - features['units_sold_w3']) / (features['units_sold_w3'] + 1e-6)
    # Average Order Value per window
    features['aov_w1'] = features['total_revenue_w1'] / (features['num_orders_w1'] + 1e-6)
    features['aov_w2'] = features['total_revenue_w2'] / (features['num_orders_w2'] + 1e-6)
    features['aov_w3'] = features['total_revenue_w3'] / (features['num_orders_w3'] + 1e-6)
    # Freight to revenue ratio per window
    features['freight_ratio_w1'] = features['total_freight_w1'] / (features['total_revenue_w1'] + 1e-6)
    features['freight_ratio_w2'] = features['total_freight_w2'] / (features['total_revenue_w2'] + 1e-6)
    # Order success rate per window
    features['success_rate_w1'] = features['num_successful_orders_w1'] / (features['num_orders_w1'] + 1e-6)
    features['success_rate_w2'] = features['num_successful_orders_w2'] / (features['num_orders_w2'] + 1e-6)
    # Reindex to exactly match input entity IDs
    features = features.reindex(entity_ids)
    return features