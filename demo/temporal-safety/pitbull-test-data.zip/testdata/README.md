# PITBULL test data: 76 leaking feature programs (Olist)

`programs/<uid>.py`: the original, leaking version of each `get_features(db, entity_ids, seed_time)`
program used in the repair experiments (uid = first 16 hex chars of SHA-256 of the code).
`programs.csv`: program id, author model, leakage mechanism, and the iteration at which the
direct F1 repair loop first produced a clean candidate (`a2_clean_at`, empty = never).
`olist-profile.json`: the data profile used by the demo page.

Database: Brazilian E-Commerce Public Dataset by Olist (Kaggle,
https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce, CC BY-NC-SA 4.0).
Put the CSV files into a folder and point `P3_OLIST` at it.

Prediction times: development 2018-01-01, 2018-04-01, 2018-07-01;
held-out 2017-10-01, 2018-02-01, 2018-06-01.

Check one program with the skill: `pit-check --code programs/<uid>.py`
(see SKILL.md, section "Preconditions").
